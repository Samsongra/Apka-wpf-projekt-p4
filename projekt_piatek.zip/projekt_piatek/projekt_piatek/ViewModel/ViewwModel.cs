﻿using projekt_piatek;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using projekt_piatek.Commands;


namespace projekt_piatek.ViewModel
{
    public class ViewwModel : BaseViewModel
    {


        private void DisplayMessage()
        {
            MessageBox.Show("Dane zostały wysłane do bazy!", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        public ICommand ClickCommand
        {
            get;
            private set;
        }
        public ICommand UpdateViewCommand { get; set; }
        public ViewwModel()
        {
            UpdateViewCommand = new UpdateViewCommand(this);
        }
        private BaseViewModel _selectedViewModel;

        public BaseViewModel SelectedViewModel
        {
            get { return _selectedViewModel; }
            set
            {
                _selectedViewModel = value;
                OnPropertyChanged(nameof(SelectedViewModel));
            }
        }
    }
}
