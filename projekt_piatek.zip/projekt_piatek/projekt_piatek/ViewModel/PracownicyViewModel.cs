﻿using projekt_piatek;

using projekt_piatek.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;


namespace projekt_piatek.ViewModel
{
    public class PracownicyViewModel : BaseViewModel
    {
        public ICommand DodajPracownikaCommand { get; }
        public ICommand EdytujPracownikaCommand { get; set; }
        public ICommand UsunPracownikaCommand { get; set; }

        private Pracownicy _pracownicy;

        public PracownicyViewModel() {
            DodajPracownikaCommand = new DodajPracownikaCommand(this);
            EdytujPracownikaCommand = new EdytujPracownikaCommand(this);
            UsunPracownikaCommand = new UsunPracownikaCommand(this);
            _pracownicy = new Pracownicy();
        }
        
        public int IdP
        {
            get { return _pracownicy.IdP; }
            set
            {
                if (_pracownicy.IdP != value)
                {
                    _pracownicy.IdP = value;
                    OnPropertyChanged(nameof(IdP));
                }
            }
        }
        public string Imie
        {
            get { return _pracownicy.Imie; }
            set
            {
                if (_pracownicy.Imie != value)
                {
                    _pracownicy.Imie = value;
                    OnPropertyChanged(nameof(Imie));
                }
            }
        }
             public string Nazwisko
        {
            get { return _pracownicy.Nazwisko; }
            set
            {
                if (_pracownicy.Nazwisko != value)
                {
                    _pracownicy.Nazwisko = value;
                    OnPropertyChanged(nameof(Nazwisko));
                }
            }
        }
         public int Pesel
        {
            get { return _pracownicy.Pesel; }
            set
            {
                if (_pracownicy.Pesel != value)
                {
                    _pracownicy.Pesel = value;
                    OnPropertyChanged(nameof(Pesel));
                }
            }
        }
             public string Miasto
        {
            get { return _pracownicy.Miasto; }
            set
            {
                if (_pracownicy.Miasto != value)
                {
                    _pracownicy.Miasto = value;
                    OnPropertyChanged(nameof(Miasto));
                }
            }
        }
             public string Ulica
        {
            get { return _pracownicy.Ulica; }
            set
            {
                if (_pracownicy.Ulica != value)
                {
                    _pracownicy.Ulica = value;
                    OnPropertyChanged(nameof(Ulica));
                }
            }
        }
             public int KodPocztowy
        {
            get { return _pracownicy.KodPocztowy; }
            set
            {
                if (_pracownicy.KodPocztowy != value)
                {
                    _pracownicy.KodPocztowy = value;
                    OnPropertyChanged(nameof(KodPocztowy));
                }
            }
        }
             public int NrTelefonu
        {
            get { return _pracownicy.NrTelefonu; }
            set
            {
                if (_pracownicy.NrTelefonu != value)
                {
                    _pracownicy.NrTelefonu = value;
                    OnPropertyChanged(nameof(NrTelefonu));
                }
            }
        }
        
    }
}




