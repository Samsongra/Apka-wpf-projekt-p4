﻿using projekt_piatek.ViewModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace projekt_piatek.Commands
{
    internal class EdytujPracownikaCommand : ICommand
    {
        public readonly PracownicyViewModel pracownicyViewModel;
        public EdytujPracownikaCommand(PracownicyViewModel vm)
        {
            pracownicyViewModel = vm;
            vm.PropertyChanged += OnPropertyChanged;
        }

        private void OnPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            OnCanExecuteChanged();
        }
        protected virtual void OnCanExecuteChanged() => CanExecuteChanged?.Invoke(this, new EventArgs());

        public event EventHandler? CanExecuteChanged;

        public bool CanExecute(object? parameter)
        {
            return (pracownicyViewModel.Imie != "" & pracownicyViewModel.Nazwisko != "" & pracownicyViewModel.Pesel != 0
                && pracownicyViewModel.KodPocztowy != 0 && pracownicyViewModel.NrTelefonu != 0 && pracownicyViewModel.IdP != 0);
        }

        public void Execute(object? parameter)
        {
            try
            {
                using Context context = new();
                context.SaveChanges();
                MessageBox.Show("Zapisano zmiany");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Nie udało się zapisać zmian: {ex.Message}");
            }
        }
    }
}
