﻿using projekt_piatek.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace projekt_piatek.Commands
{
    internal class UpdateViewCommand : ICommand
    {
        private ViewwModel viewwModel;

        public event EventHandler CanExecuteChanged;
        public UpdateViewCommand(ViewwModel viewModel)
        {
            this.viewwModel = viewModel;
        }

        public bool CanExecute(object? parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            if (parameter.ToString() == "Pracownicy")
            {
                viewwModel.SelectedViewModel = new PracownicyViewModel();
            }
            else if (parameter.ToString() == "Liczenie")
            {
                viewwModel.SelectedViewModel = new GodzinyPracyPracownicy();
            }
        }
    }
}
