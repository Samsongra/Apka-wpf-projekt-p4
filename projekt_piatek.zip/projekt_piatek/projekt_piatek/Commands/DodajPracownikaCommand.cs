﻿using projekt_piatek;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using projekt_piatek.ViewModel;

namespace projekt_piatek.Commands {
    internal class DodajPracownikaCommand : ICommand {
        public readonly PracownicyViewModel pracownicyViewModel;

        public DodajPracownikaCommand(PracownicyViewModel vm) {
            pracownicyViewModel = vm;
            vm.PropertyChanged += OnPropertyChanged;
        }

        public event EventHandler? CanExecuteChanged;

        public virtual bool CanExecute(object? parameter) {
            return (pracownicyViewModel.Imie != "" & pracownicyViewModel.Nazwisko != "" & pracownicyViewModel.Pesel != 0
                && pracownicyViewModel.KodPocztowy != 0 && pracownicyViewModel.NrTelefonu != 0 && pracownicyViewModel.IdP != 0);
        }
        private void OnPropertyChanged(object sender, PropertyChangedEventArgs e) {
                OnCanExecuteChanged();
        }
        protected virtual void OnCanExecuteChanged() => CanExecuteChanged?.Invoke(this, new EventArgs());
        
        public void Execute(object? parameter) {
            try {
                using Context context = new();
                context.Pracownicy.Add(new Pracownicy {
                    Imie = pracownicyViewModel.Imie,
                    Nazwisko = pracownicyViewModel.Nazwisko,
                    Pesel = pracownicyViewModel.Pesel,
                    Miasto = pracownicyViewModel.Miasto,
                    Ulica = pracownicyViewModel.Ulica,
                    KodPocztowy = pracownicyViewModel.KodPocztowy,
                    NrTelefonu = pracownicyViewModel.NrTelefonu
                });
                context.SaveChanges();
                MessageBox.Show("Dodano pracownika");
            } catch (Exception ex) {
                MessageBox.Show($"Nie udało się dodać pracownika: {ex.Message}");
            }
        }
    }
}
