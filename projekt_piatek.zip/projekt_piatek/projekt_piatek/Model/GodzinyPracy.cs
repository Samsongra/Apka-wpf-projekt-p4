﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projekt_piatek.Model
{
    internal class GodzinyPracy
    {
        [Key]
        public int IdP { get; set; }
        public DateTime GodzinaOd { get; set; }
        public DateTime GodzinaDo { get; set; }

        public GodzinyPracy() { }

        public GodzinyPracy(int IdP, DateTime GodzinaOd, DateTime GodzinaDo)
        {
            this.IdP = IdP;
            this.GodzinaDo = GodzinaDo;
            this.GodzinaOd = GodzinaOd;
        }
    }
}
