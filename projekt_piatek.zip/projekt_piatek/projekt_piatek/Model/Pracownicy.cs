﻿using System.ComponentModel.DataAnnotations;

namespace projekt_piatek
{
    public class Pracownicy
    {
        [Key]
        public int IdP { get; set; }
        public string Imie { get; set; }
        public string Nazwisko { get; set; }
        public int Pesel { get; set; }
        public string Miasto { get; set; }
        public string Ulica { get; set; }
        public int KodPocztowy { get; set; }
        public int NrTelefonu { get; set; }

        public Pracownicy() { }

        public Pracownicy(int IdP, string Imie, string Nazwisko, int Pesel, string Miasto, string Ulica, int KodPocztowy, int NrTelefonu) {
            this.IdP = IdP;
            this.Imie = Imie;
            this.Nazwisko = Nazwisko;
            this.Pesel = Pesel;
            this.Miasto = Miasto;
            this.Ulica = Ulica;
            this.KodPocztowy = KodPocztowy;
            this.NrTelefonu = NrTelefonu;
        }
    }
}